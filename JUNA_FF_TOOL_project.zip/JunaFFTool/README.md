# JUNA FF TOOL

Android starter project with a black/blue premium interface and custom launcher icon.

## Build APK from a phone
1. Upload this project ZIP to a new GitHub repository (extract it first).
2. Open the repository's **Actions** tab.
3. Run **Build Android APK** (or push to `main`).
4. Open the completed workflow run and download the `JUNA-FF-TOOL-debug` artifact.
5. Extract the artifact ZIP to get `app-debug.apk`.

This is a practice/training companion only. It does not modify Free Fire or include ESP, automatic aim, or anti-cheat bypass.
