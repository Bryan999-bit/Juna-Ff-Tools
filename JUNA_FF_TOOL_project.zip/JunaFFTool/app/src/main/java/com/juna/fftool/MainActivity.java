package com.juna.fftool;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.ImageView;

public class MainActivity extends Activity {
    private final int bg = Color.rgb(8, 12, 24);
    private final int panel = Color.rgb(17, 25, 43);
    private final int blue = Color.rgb(35, 145, 255);
    private LinearLayout content;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(bg);
        getWindow().setNavigationBarColor(bg);

        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(bg);
        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(20), dp(22), dp(20), dp(28));
        scroll.addView(content);
        setContentView(scroll);

        ImageView logo = new ImageView(this);
        logo.setImageResource(com.juna.fftool.R.drawable.juna_logo);
        logo.setScaleType(ImageView.ScaleType.FIT_CENTER);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(112), dp(112));
        lp.gravity = Gravity.CENTER_HORIZONTAL;
        content.addView(logo, lp);

        TextView title = text("JUNA FF TOOL", 25, Color.WHITE, true);
        title.setGravity(Gravity.CENTER);
        content.addView(title);
        TextView sub = text("PREMIUM GAMING COMPANION", 10, 0xFF7EBAFF, true);
        sub.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams subLp = new LinearLayout.LayoutParams(-1, -2);
        subLp.bottomMargin = dp(22);
        content.addView(sub, subLp);

        addSection("TOOLS");
        addCard("Aim Trainer", "Latihan refleks dan akurasi secara offline", "BUKA", "Aim Trainer membantu latihan target tanpa terhubung ke Free Fire.");
        addCard("Sensitivity Assistant", "Catat dan sesuaikan preferensi sensitivitas", "BUKA", "Atur sensitivitas berdasarkan kenyamananmu. Tidak mengubah file atau kontrol game.");
        addCard("HUD Optimizer", "Panduan menata tombol HUD", "BUKA", "Atur tata letak HUD langsung melalui pengaturan resmi di dalam game.");
        addSection("ABOUT");
        TextView note = text("Versi 1.0 • Tools latihan dan pengaturan pribadi. Aplikasi ini tidak memodifikasi Free Fire, tidak menyediakan ESP, aim lock, atau bypass anti-cheat.", 12, 0xFF9AAAC4, false);
        note.setPadding(dp(4), dp(8), dp(4), dp(8));
        content.addView(note);
    }

    private void addSection(String label) {
        TextView t = text(label, 12, 0xFF75B7FF, true);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.topMargin = dp(10); p.bottomMargin = dp(10);
        content.addView(t, p);
    }

    private void addCard(String name, String desc, String action, String message) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(16), dp(15), dp(16), dp(15));
        card.setBackground(round(panel, 18, 0xFF263B5C));
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-1, -2);
        cp.bottomMargin = dp(12);
        content.addView(card, cp);

        TextView heading = text(name, 17, Color.WHITE, true);
        card.addView(heading);
        TextView detail = text(desc, 12, 0xFF9EACC2, false);
        LinearLayout.LayoutParams dp = new LinearLayout.LayoutParams(-1, -2);
        dp.topMargin = dp(5); dp.bottomMargin = dp(12);
        card.addView(detail, dp);

        TextView button = text(action + "  →", 12, Color.WHITE, true);
        button.setGravity(Gravity.CENTER);
        button.setPadding(dp(16), dp(10), dp(16), dp(10));
        button.setBackground(round(blue, 12, blue));
        button.setOnClickListener(v -> showInfo(message));
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(-1, -2);
        card.addView(button, bp);
    }

    private void showInfo(String message) {
        new android.app.AlertDialog.Builder(this)
            .setTitle("JUNA FF TOOL")
            .setMessage(message)
            .setPositiveButton("OK", null)
            .show();
    }

    private TextView text(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private GradientDrawable round(int color, int radius, int stroke) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color); d.setCornerRadius(dp(radius));
        d.setStroke(dp(1), stroke);
        return d;
    }
    private int dp(int v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }
}
